/*****PLEASE ENTER YOUR DETAILS BELOW*****/
--T2-pat-insert.sql

--Student ID:
--Student Name:

/* Comments for your marker:




*/

--------------------------------------
--INSERT INTO official
--------------------------------------



--------------------------------------
--INSERT INTO vehicle
--------------------------------------



--------------------------------------
--INSERT INTO trip
--------------------------------------
