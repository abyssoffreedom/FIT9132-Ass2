/*****PLEASE ENTER YOUR DETAILS BELOW*****/
--T3-pat-dml.sql

--Student ID:
--Student Name:

/* Comments for your marker:




*/

/*(a)*/



/*(b)*/



/*(c)*/



/*(d)*/

